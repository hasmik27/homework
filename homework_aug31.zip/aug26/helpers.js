import fs from 'fs/promises'

export async function getFileData(){
    try {
        const dataStr = await fs.readFile('./db.json') // json
        return JSON.parse(dataStr)
    } catch(err){
        return err
    }
}

export const getTodosFromDB = async () => {
    const data = await getFileData()
    return data.todos
}

export const getNextTodoId = async () => {
    const data = await getFileData()
    return data.nextTodoId
}

export async function setNextTodo(addedData){
    let {todos, nextTodoId} = await getFileData()
    addedData.id = nextTodoId
    addedData.isCompleted = false
    todos.push(addedData)
    nextTodoId += 1
    fs.writeFile('./db.json', JSON.stringify({"todos": todos, "nextTodoId": nextTodoId}))
}


export async function updateData(req, addedData, id){
    const {todos, nextTodoId} = await getFileData()
    const existedTodoId = todos.findIndex(item => item.id === id)
    if(req.method === 'PUT'){
        for(let key in todos[existedTodoId]){
            todos[existedTodoId][key] = addedData[key]
        }
        fs.writeFile('./db.json', JSON.stringify({"todos": todos, "nextTodoId": nextTodoId}))
    }
    else if(req.method === 'PATCH'){
        for(let key in todos[existedTodoId]){
            if(addedData.hasOwnProperty(key)){
                todos[existedTodoId][key] = addedData[key]
            }
        }
        fs.writeFile('./db.json', JSON.stringify({"todos": todos, "nextTodoId": nextTodoId}))
    }
}


export async function deleteTodo(id){
    let {todos, nextTodoId} = await getFileData()
    todos = todos.filter(item => item.id !== id)
    fs.writeFile('./db.json', JSON.stringify({"todos": todos, "nextTodoId": nextTodoId}))
}

export function commingData(req){
    return new Promise((res, rej) => {
        let commingData = ''
        req.on('data', (chunk) => {
            commingData += String(chunk)
        })
        req.on('end', () => {
            res(JSON.parse(commingData))
        })
    })

}
