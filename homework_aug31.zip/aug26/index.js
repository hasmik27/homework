import { createServer } from 'http'
import {  todosHandler } from './requestHandlers/todosHandler.js';

const hostname = '127.0.0.1'
const port = 3000;

const server = createServer(async function(req, res){
    res.writeHead(200, { 'Content-Type': 'application/json' })
    // res.setHeader('Content-Type', 'application/json')
    const todos = '/API/v1/todos'
    if(req.url?.startsWith(todos)){
        req.url = req.url.slice(todos.length)
        todosHandler(req, res)
    } 
    else {
        res.writeHead(404, { 'Content-Type': 'application/json' })
        res.end(JSON.stringify({ message: 'Route Not Found' }))
    }
})

server.listen(port, hostname,() => {
    console.log(`Server running at http://${hostname}:${port}/`);
})