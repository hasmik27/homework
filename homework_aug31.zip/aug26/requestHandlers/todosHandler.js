import { getTodosFromDB, setNextTodo, commingData, deleteTodo, updateData } from '../helpers.js';

export async function todosHandler(req, res){
    const url = req.url.slice(1)
    const ind = url.indexOf('/')
    if(req.url === '' || req.url === '/'){
        if(req.method === 'GET'){
            const data = await getTodosFromDB()
            res.end(JSON.stringify(data))
        }
        else if(req.method === 'POST'){
            const comdata = await commingData(req)
            setNextTodo(comdata)          
        }
    } 
    else if(ind === -1 || url[ind + 1] === undefined){
        const id = +(url.split('/')[0])
        const data = await getTodosFromDB()
        const existedTodoId = data.findIndex(item => item.id === id)
        if(!isNaN(id) && existedTodoId !== -1){
            if( req.method === 'GET'){
                const byId = data.find(item => item.id === id)
                res.end(JSON.stringify(byId))  
            }
            else if(req.method === 'DELETE'){
                deleteTodo(id)
            }
            else if(req.method === 'PUT' || req.method === 'PATCH'){
                const comdata = await commingData(req)
                updateData(req, comdata, id)
            }
        } else {
            res.writeHead(404, { 'Content-Type': 'application/json' })
            res.end(JSON.stringify({ error: 'ToDo with requested ID does not exist' }))
        }
    }
    else {
        res.writeHead(400, { 'Content-Type': 'application/json' })
        res.end(JSON.stringify({ error: 'Route Not Found' }))
    }
}
