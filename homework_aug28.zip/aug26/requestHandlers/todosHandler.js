import { getTodosFromDB, setNextTodo} from '../helpers.js';
// import fs from 'fs/promises'

export async function todosHandler(req, res){
    const data = await getTodosFromDB()
    const url = req.url.slice(1)
    const ind = url.indexOf('/')
    if(req.url === '' || req.url === '/'){
        if(req.method === 'GET'){
            res.end(JSON.stringify(data))
        }
        else if(req.method === 'POST'){
            let commingData = ''
            req.on('data', (chunk) => {
                commingData += String(chunk)
            })
            req.on('end', () => {
                const addedData = JSON.parse(commingData)
                setNextTodo(addedData)
            })           
        }
    } 
    else if((ind === -1 || url[ind + 1] === undefined) && req.method === 'GET'){
        const id = url.split('/')[0]
        if(!isNaN(+id)){
            data.forEach((item, index) => {
                if(item.id === +id){
                    res.end(JSON.stringify(data[index]))    
                }
                // res.end(JSON.stringify('There is no ToDo with requested ID'))
            }) 
        }
    
    }
}

