import { createServer } from 'http'
// import fs from 'fs/promises'

import {  todosHandler } from './requestHandlers/todosHandler.js';

const hostname = '127.0.0.1'
const port = 3000;

// getTodosFromDB().then(todos => console.log(todos))


const server = createServer(async function(req, res){
    // res.writeHead(200, { 'Content-Type': 'application/json' })
    res.setHeader('Content-Type', 'application/json')
    if(req.url?.startsWith('/todos')){
        const t = '/todos'
        req.url = req.url.slice(t.length)
        todosHandler(req, res)
    } 
    else {
        res.end(JSON.stringify('ERROR'))
    }
    
})

server.listen(port, hostname,() => {
    console.log(`Server running at http://${hostname}:${port}/`);
})