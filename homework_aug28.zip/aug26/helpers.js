import fs from 'fs/promises'

export async function getFileData(){
    try {
        const dataStr = await fs.readFile('./db.json') // json
        return JSON.parse(dataStr)
    } catch(err){
        return err
    }
}

export const getTodosFromDB = async () => {
    const data = await getFileData()
    return data.todos
}

export const getNextTodoId = async () => {
    const data = await getFileData()
    return data.nextTodoId
}

export async function setNextTodo(addedData){
        const alldata = await getFileData()
        const nextId = await getNextTodoId()
        addedData.id = nextId
        addedData.isCompleted = false
        alldata.todos.push(addedData)
        alldata.nextTodoId +=1
        fs.writeFile('./db.json', JSON.stringify(alldata))
}