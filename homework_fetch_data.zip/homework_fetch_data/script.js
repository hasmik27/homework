

function fetchData(url) {
    const BASE_URL = 'https://ghibliapi.herokuapp.com/'
    const newUrl = url.startsWith('/') ? url.slice(1) : url
    return fetch(`${BASE_URL}${newUrl}`).then((res) => res.json())
}

function fetchFilm(filmUrl){
  return fetch(filmUrl).then((res) => res.json())
}


  
  init()
  
  function init() {
    const rootEl = document.querySelector('#root')
    const divEl = App()
    rootEl.append(divEl)
  }
  

  function App() {
    // const template = document
    //   .querySelector('#app-template')
    //   .content.cloneNode(true)

  
    const container = document.createElement('div')
    container.setAttribute('component-name', 'App')

    const state = {
      people: [],
      filmUrl: [],
      imageURl: []
    }

    window.state = state
  

    function setState(obj) {
      for (let key in obj) {
        state[key] = obj[key]
      }
      render()
    }

    fetchData('people').then((data) => {
      setState({ people: data })
      
      data.forEach((item, index) => {
        fetchFilm(item.films).then(res => {
          Object.defineProperty(state.people[index], "image", {
            value: res.image,
            enumerable: true
          });
          // state.people[index].image = res.image
        })
      })
    })

    function render() {
      container.innerHTML = ''
      const peopleEl = People(state.people)
      container.append(peopleEl)
    }
  

    render()

    return container
  }

  
  function People(people) {

    // const template = document
    //   .querySelector('#people-template')
    //   .content.cloneNode(true)

      const container = document.createElement('div')
      container.setAttribute('component-name', 'People')
      container.classList.add('people')

    

    console.log(people[0])
    people.forEach(({ name, age, gender, eye_color, hair_color, image}) => {
      console.log(image)
      const userEl = Person(name, age, gender, eye_color, hair_color, image)
      container.append(userEl)
    })
  

    return container
  }
  


  function Person(name, age, gender, eye_color, hair_color, image ) {
    const template = document
      .querySelector('#person-template')
      .content.cloneNode(true)

  
    
    template.querySelector('.name').innerHTML = `Name: ${name}`
    template.querySelector('.age').innerHTML = `${age} years old`
    template.querySelector('.gender').innerHTML = `Gender: ${gender}`
    template.querySelector('.eye_color').innerHTML = `Eye color: ${eye_color}`
    template.querySelector('.hair_color').innerHTML = `Hair color: ${hair_color}`
    // template.querySelector('.image').src = image

    // template.querySelector('#btn').onclick = function(){
    //   if(img.style.display === 'none'){
    //     img.style.display === 'block'
    //   }
    // }
    // let img = template.querySelector('.image')
    

    return template
  }

